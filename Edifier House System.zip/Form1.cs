﻿
//  Author: PHNO - Technologist | Postgraduate in Photovoltaic Solar Energy
//  Release Date: 29/09/2024
//  Version: 0.0.0.4v
//  Replit: @PHNO, @PHREPLIT
//  E-mail: phreplit@gmail.com

// Software: Edifier House - System - 0.0.0.4v - Measurement and Calculation for Civil Engineering, with GUI [graphical interface] and compilation in desktop environment.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Text = "Info";
            // classe, metodo, string(texto)
            MessageBox.Show("Info\n"
                + "\nTo calculate the Land Area [Square Meter] - Regular Size Land [4 equal sides] - we will calculate the width multiplied by the length."
                + "\nTo calculate the Perimeter of a Land [Meters in Sequence] - Regular Size Land [4 equal sides] - we will add all the sides and obtain the meter in sequence."
                + "\nTo calculate the Property Area [Square Meter] - Regular Sized Plot [4 equal sides] - we will calculate the width multiplied by the length."
                + "\nTo calculate the Property Perimeter [Meters in Sequence] - Regular Sized Plot [4 equal sides] - we will add all the sides and obtain the meter in sequence."
                + "\nTo calculate the Area of a Wall [Square Meter] - Regular Size Wall [4 equal sides] - we will calculate the height multiplied by the width.."
                + "\nTo calculate the Area of a Built House [Square Meter] - Regular Size Walls [4 equal sides] - we will calculate the square meters of a wall multiplied by the number of sides of the house."
                + "\nTo calculate the Area of a Built Room [Square Meter] - Regular Size Wall [4 equal sides] - we will calculate the square meters of a wall multiplied by the number of sides of the room."
                + "\nTo calculate the amount of brickwork blocks to build a wall, we will calculate the square meters of a wall times 25, which is equivalent to one square meter with 25 brickwork blocks.");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Text = "About";
            MessageBox.Show("About\n" + "\nSoftware: Edifier House - System - 0.0.0.4v - Measurement and Calculation for Civil Engineering \n" + "\nAuthor: PHNO" + "\nRelease Date: 29/09/2024" + "\nVersion: 0.0.0.4v" + "\nReplit: @PHNO, @PHREPLIT" + "\nE-mail: phreplit@gmail.com");

        }

        private void button3_Click(object sender, EventArgs e) // Land Area [Square Meter]
        {
            if (int.TryParse(textBox1.Text, out int numero1) && int.TryParse(textBox2.Text, out int numero2))
            {
                int mult = numero1 * numero2;

                textBox3.Text = ("" + mult);
            }
            else
            {
                textBox3.Text = "Error. enter required field.";
            }


        }

        private void button4_Click(object sender, EventArgs e) // Land Perimeter [Square Meter]
        {
            if (int.TryParse(textBox4.Text, out int numero3) && int.TryParse(textBox5.Text, out int numero4))
            {
                int numero5 = 2;
                int mult2 = numero3 + numero4;
                int result = mult2 * numero5;

                textBox6.Text = ("" + result);
            }
            else
            {
                textBox6.Text = "Error. enter required field.";
            }

        }

        private void button5_Click(object sender, EventArgs e) // Property Area [Square Meter]
        {
            if (int.TryParse(textBox7.Text, out int numero6) && int.TryParse(textBox8.Text, out int numero7))
            {
                int mult3 = numero6 * numero7;

                textBox9.Text = ("" + mult3);
            }
            else
            {
                textBox9.Text = "Error. enter required field.";
            }
        }

        private void button6_Click(object sender, EventArgs e) // Property Perimeter [Square Meter]
        {
            if (int.TryParse(textBox10.Text, out int numero8) && int.TryParse(textBox11.Text, out int numero9))
            {
                int numero10 = 2;
                int mult4 = numero8 + numero9;
                int result2 = mult4 * numero10;

                textBox12.Text = ("" + result2);
            }
            else
            {
                textBox12.Text = "Error. enter required field.";
            }
        }

        private void button7_Click(object sender, EventArgs e) // Wall Area [Square Meter]
        {
            if (int.TryParse(textBox13.Text, out int numero11) && int.TryParse(textBox14.Text, out int numero12))
            {
                int numero13 = 25;
                int result3 = numero11 * numero12;
                int result4 = result3 * numero13;

                textBox15.Text = ("" + result3);
                textBox20.Text = ("" + result4);
            }
            else
            {
                textBox15.Text = "Error. enter required field.";
                textBox20.Text = "Error. enter required field.";
            }
        }

        private void button8_Click(object sender, EventArgs e) // Built Area of ​​House [Square Meter]
        {
            if (int.TryParse(textBox16.Text, out int numero14) && int.TryParse(textBox17.Text, out int numero15))
            {
                int numero16 = 25;
                int result5 = numero14 * numero15;
                int result6 = result5 * numero16;

                textBox18.Text = ("" + result5);
                textBox19.Text = ("" + result6);
            }
            else
            {
                textBox18.Text = "Error. enter required field.";
                textBox19.Text = "Error. enter required field.";
            }
        }

        private void button9_Click(object sender, EventArgs e) // Built Area of ​​the room [Square Meter]
        {
            if (int.TryParse(textBox21.Text, out int numero17) && int.TryParse(textBox22.Text, out int numero18))
            {
                int numero19 = 25;
                int result7 = numero17 * numero18;
                int result8 = result7 * numero19;

                textBox23.Text = ("" + result7);
                textBox24.Text = ("" + result8);
            }
            else
            {
                textBox23.Text = "Error. enter required field.";
                textBox24.Text = "Error. enter required field.";
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Text = "Edifier House - System - 0.0.0.4v - Measurement and Calculation for Civil Engineering";
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear(); // call clear method
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            textBox13.Clear();
            textBox14.Clear();
            textBox15.Clear();
            textBox16.Clear();
            textBox17.Clear();
            textBox18.Clear();
            textBox19.Clear();
            textBox20.Clear();
            textBox21.Clear();
            textBox22.Clear();
            textBox23.Clear();
            textBox24.Clear();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int numero1) && int.TryParse(textBox2.Text, out int numero2))
            {
                this.Text = "Edifier House - System - 0.0.0.4v - Measurement and Calculation for Civil Engineering";
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear(); // call clear method
            }
            else
            {
                textBox3.Text = "Error. nothing to clear.";
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox4.Text, out int numero3) && int.TryParse(textBox5.Text, out int numero4))
            {
                this.Text = "Edifier House - System - 0.0.0.4v - Measurement and Calculation for Civil Engineering";
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear(); // call clear method
            }
            else
            {
                textBox6.Text = "Error. nothing to clear.";
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox7.Text, out int numero6) && int.TryParse(textBox8.Text, out int numero7))
            {
                this.Text = "Edifier House - System - 0.0.0.4v - Measurement and Calculation for Civil Engineering";
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear(); // call clear method
            }
            else
            {
                textBox9.Text = "Error. nothing to clear.";
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox10.Text, out int numero8) && int.TryParse(textBox11.Text, out int numero9))
            {
                this.Text = "Edifier House - System - 0.0.0.4v - Measurement and Calculation for Civil Engineering";
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear(); // call clear method
            }
            else
            {
                textBox12.Text = "Error. nothing to clear.";
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox13.Text, out int numero11) && int.TryParse(textBox14.Text, out int numero12))
            {
                this.Text = "Edifier House - System - 0.0.0.4v - Measurement and Calculation for Civil Engineering";
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear(); // call clear method
                textBox20.Clear();
            }
            else
            {
                textBox15.Text = "Error. nothing to clear.";
                textBox20.Text = "Error. nothing to clear.";
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox16.Text, out int numero14) && int.TryParse(textBox17.Text, out int numero15))
            {
                this.Text = "Edifier House - System - 0.0.0.4v - Measurement and Calculation for Civil Engineering";
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear(); // call clear method
                textBox19.Clear();
            }
            else
            {
                textBox18.Text = "Error. nothing to clear.";
                textBox19.Text = "Error. nothing to clear.";
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox21.Text, out int numero17) && int.TryParse(textBox22.Text, out int numero18))
            {
                this.Text = "Edifier House - System - 0.0.0.4v - Measurement and Calculation for Civil Engineering";
                textBox21.Clear(); // call clear method
                textBox22.Clear();
                textBox23.Clear();
                textBox24.Clear();
            }
            else
            {
                textBox23.Text = "Error. nothing to clear.";
                textBox24.Text = "Error. nothing to clear.";
            }
        }
    }
}
